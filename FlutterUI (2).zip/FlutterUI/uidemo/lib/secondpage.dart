import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uidemo/third.dart';

class secondpage extends StatefulWidget {
  secondpage({super.key});

  @override
  State<secondpage> createState() => _secondpageState();
}

class _secondpageState extends State<secondpage> {
  bool isbuttomClicked = true;
  int myindex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
          onTap: (index) {
            setState(() {
              myindex = index;
              print(myindex);
            });
          },
          currentIndex: myindex,
          items: [
            const BottomNavigationBarItem(icon: Icon(Icons.home), label: ""),
            const BottomNavigationBarItem(
                icon: Icon(Icons.access_time), label: ""),
            BottomNavigationBarItem(
                icon: Icon(Icons.heart_broken_sharp), label: ""),
            // BottomNavigationBarItem(icon: Icon(Icons.person), label: "")
          ]),
      // appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Text("Hi David 👋",
                              style: GoogleFonts.montserrat(
                                textStyle: const TextStyle(
                                    fontSize: 30, fontWeight: FontWeight.bold),
                              )),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          "Explore the world",
                          style: GoogleFonts.inter(
                              textStyle: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.normal,
                                  color: Color.fromARGB(255, 148, 145, 145))),
                        ),
                      ],
                    )
                  ],
                ),
                const CircleAvatar(
                  backgroundImage: AssetImage(
                      "asset/pexels-andrea-piacquadio-3777946 2.png"),
                  radius: 25,
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 25, left: 10, right: 10),
              child: Container(
                child: TextField(
                  decoration: InputDecoration(
                    hintText:
                        "search places                                                                      |",
                    suffixIcon: Image.asset("asset/icon setting.png"),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20)),
                  ),
                  maxLines: 1,
                ),
              ),
            ),
            SizedBox(
              width: 100,
              height: 20,
            ),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 12, right: 12),
                      child: const Column(
                        children: [
                          Text(
                            "popular places",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15),
                          )
                        ],
                      ),
                    ),
                    TextButton(
                        onPressed: () {},
                        child: const Text(
                          "viewall",
                          style: TextStyle(
                              color: Color.fromARGB(255, 120, 118, 118)),
                        )),
                  ],
                ),
                SizedBox(
                  width: 100,
                  height: 15,
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 12, right: 12),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: isbuttomClicked
                                ? const Color.fromARGB(177, 149, 143, 143)
                                : Colors.black,
                          ),
                          onPressed: () {
                            setState(() {
                              isbuttomClicked = !isbuttomClicked;
                            });
                          },
                          child: const Text(
                            "Most viewed",
                            style: TextStyle(color: Colors.white),
                          )),
                      TextButton(
                          style: const ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(
                                  Color.fromARGB(177, 149, 143, 143))),
                          onPressed: () {},
                          child: const Text(
                            "Nearby",
                            style: TextStyle(color: Colors.white),
                          )),
                      TextButton(
                          style: const ButtonStyle(
                              backgroundColor: MaterialStatePropertyAll(
                                  Color.fromARGB(177, 149, 143, 143))),
                          onPressed: () {},
                          child: const Text(
                            "Latest",
                            style: TextStyle(color: Colors.white),
                          ))
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Card(
                          elevation: 50,
                          child: Container(
                            height: 350,
                            width: 250,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                image: const DecorationImage(
                                    fit: BoxFit.cover,
                                    image: AssetImage(
                                      "asset/Mask group.jpg",
                                    ))),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Align(
                                      alignment: Alignment.topRight,
                                      child:
                                          Image.asset("asset/heart icon.png")),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  width: 200,
                                  height: 75,
                                  decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            Color.fromARGB(227, 33, 349, 243),
                                            Colors.black
                                          ]),
                                      borderRadius: BorderRadius.circular(15)),
                                  child: const Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Mount Fuji,Tokyo",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          Row(
                                            children: [
                                              Icon(Icons.location_on_outlined),
                                              Text(
                                                "Tokyo,japan",
                                                style: TextStyle(
                                                    color: Colors.grey),
                                              ),
                                              SizedBox(
                                                width: 30,
                                              ),
                                              Icon(Icons.star_rate_rounded),
                                              Text(
                                                "4.0,",
                                                style: TextStyle(
                                                    color: Colors.grey),
                                              )
                                            ],
                                          )
                                        ]),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                          width: 20,
                        ),
                        Row(
                          children: [
                            Card(
                              elevation: 50,
                              child: Container(
                                height: 350,
                                width: 250,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    image: const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                            "asset/Mask group.jpg"))),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.of(context)
                                        .push(MaterialPageRoute(
                                      builder: (context) => Third(),
                                    ));
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: 10),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          width: 230,
                                          height: 75,
                                          decoration: BoxDecoration(
                                              gradient: const LinearGradient(
                                                  begin: Alignment.topCenter,
                                                  end: Alignment.bottomCenter,
                                                  colors: [
                                                    Color.fromARGB(
                                                        227, 33, 349, 243),
                                                    Colors.black
                                                  ]),
                                              borderRadius:
                                                  BorderRadius.circular(15)),
                                          child: const Padding(
                                            padding: EdgeInsets.all(8.0),
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "Andes Mountain",
                                                    style: TextStyle(
                                                        color: Colors.white),
                                                  ),
                                                  Row(
                                                    children: [
                                                      Icon(Icons
                                                          .location_on_outlined),
                                                      Text(
                                                        "South,America",
                                                        style: TextStyle(
                                                            color: Colors.grey),
                                                      ),
                                                      SizedBox(
                                                        width: 40,
                                                      ),
                                                      Icon(Icons
                                                          .star_rate_rounded),
                                                      Text(
                                                        "4.0,",
                                                        style: TextStyle(
                                                            color: Colors.grey),
                                                      )
                                                    ],
                                                  )
                                                ]),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
