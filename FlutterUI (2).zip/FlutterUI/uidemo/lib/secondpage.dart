import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uidemo/third.dart';

class secondpage extends StatelessWidget {
  const secondpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Text("Hi David",
                        style: GoogleFonts.montserrat(
                            textStyle: TextStyle(
                          fontSize: 30,
                        ))),
                    Text(
                      "Explore the world",
                      style: GoogleFonts.inter(
                          textStyle: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.normal)),
                    )
                  ],
                ),
                CircleAvatar(
                  child: Image.asset(
                    "asset/pexels-andrea-piacquadio-3777946 2.png",
                  ),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "search places",
                    suffix: Icon(Icons.dangerous_outlined),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20))),
              ),
            ),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        Text(
                          "popular places",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    TextButton(
                        onPressed: () {},
                        child: const Text(
                          "viewall",
                          style: TextStyle(color: Color.fromARGB(255, 7, 7, 7)),
                        )),
                  ],
                ),
              ],
            ),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll(
                                Color.fromARGB(255, 221, 219, 219))),
                        onPressed: () {},
                        child: const Text(
                          "Most viewed",
                          style: TextStyle(color: Colors.white),
                        )),
                    TextButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll(
                                const Color.fromARGB(255, 221, 218, 218))),
                        onPressed: () {},
                        child: const Text(
                          "Nearby",
                          style: TextStyle(color: Colors.white),
                        )),
                    TextButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll(
                                Color.fromARGB(255, 226, 224, 224))),
                        onPressed: () {},
                        child: const Text(
                          "Latest",
                          style: TextStyle(color: Colors.white),
                        ))
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 50),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Image.asset(
                          "asset/Mask group.jpg",
                          height: 350,
                        ),
                        SizedBox(
                          height: 20,
                          width: 20,
                        ),
                        Image.asset(
                          "asset/Mask group.jpg",
                          height: 350,
                        )
                      ],
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
