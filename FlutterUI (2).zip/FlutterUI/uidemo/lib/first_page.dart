import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uidemo/secondpage.dart';

class FlutterUI extends StatefulWidget {
  const FlutterUI({super.key});

  @override
  State<FlutterUI> createState() => _FlutterUIState();
}

class _FlutterUIState extends State<FlutterUI> {
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => secondpage()));
    });
    return Scaffold(
      body: Center(
        child: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color.fromARGB(227, 33, 349, 243), Colors.black])),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Travell",
                    style: GoogleFonts.lobster(
                      textStyle: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 40,
                          color: Colors.white),
                    ),
                  ),
                  InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (context) => secondpage(),
                        ));
                      },
                      child: Image.asset("asset/globe icon.png"))
                ],
              ),
              const Column(
                children: [
                  Text(
                    "Find Your Dream",
                    style: TextStyle(fontSize: 20),
                  ),
                  Text(
                    "Destination With Us",
                    style: TextStyle(fontSize: 20),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
