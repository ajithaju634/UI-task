import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Third extends StatefulWidget {
  Third({super.key});

  @override
  State<Third> createState() => _ThirdState();
}

class _ThirdState extends State<Third> {
  bool isbuttomClicked = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Card(
                elevation: 40,
                child: Container(
                  height: 350,
                  width: 400,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      image: const DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage("asset/Mask group.jpg"))),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Column(
                          children: [
                            Icon(Icons.abc),
                          ],
                        ),
                        Container(
                          width: 350,
                          height: 75,
                          decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color.fromARGB(227, 33, 349, 243),
                                    Colors.black
                                  ]),
                              borderRadius: BorderRadius.circular(15)),
                          child: const Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(left: 10.0),
                                        child: Text(
                                          "Andes Mountain",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      Text(
                                        "price",
                                        style: TextStyle(color: Colors.grey),
                                      )
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Row(
                                        children: [
                                          Icon(Icons.location_on_outlined),
                                          Text(
                                            "South,America",
                                            style:
                                                TextStyle(color: Colors.grey),
                                          ),
                                          SizedBox(
                                            width: 190,
                                          ),
                                          Text(
                                            "230",
                                            style:
                                                TextStyle(color: Colors.grey),
                                          )
                                        ],
                                      ),
                                    ],
                                  )
                                ]),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextButton(
                          style: ElevatedButton.styleFrom(
                              textStyle: isbuttomClicked
                                  ? TextStyle(color: Colors.white)
                                  : TextStyle(color: Colors.black)),
                          onPressed: () {
                            setState(() {
                              isbuttomClicked = !isbuttomClicked;
                            });
                          },
                          child: Text(
                            "Overview",
                            style: TextStyle(color: Colors.black, fontSize: 18),
                          )),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    TextButton(
                        onPressed: () {},
                        child: Text("detaisl",
                            style: TextStyle(color: Colors.black)))
                  ],
                ),
              ),
              Column(
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.access_time,
                        color: Color(0xFF9E9E9E),
                      ),
                      Text("8 hour"),
                      SizedBox(
                        width: 150,
                      ),
                      Icon(
                        Icons.cloud,
                        color: Color(0xFF9E9E9E),
                      ),
                      Text("16 c"),
                      SizedBox(
                        width: 150,
                      ),
                      Icon(
                        Icons.star,
                        color: Color(0xFF9E9E9E),
                      ),
                      Text("4.0")
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          "This vast mountain range is renowned for its remarkable diversity in terms of topography and climate. It features towering peaks, active volcanoes, deep canyons, expansive plateaus, and lush valleys. The Andes are also home to This vast mountain range is renowned for its remarkable diversity in terms of topography and climate. It features towering peaks, active volcanoes, deep canyons, expansive plateaus, and lush valleys. The Andes are also home to  ",
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                      Container(
                        width: 400,
                        height: 50,
                        decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(10)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Book Now",
                              style: TextStyle(color: Colors.white),
                            ),
                            Icon(
                              Icons.airplanemode_on_rounded,
                              color: Colors.white,
                              size: 20,
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ],
              )
            ],
          ),
        ],
      ),
    ));
  }
}
